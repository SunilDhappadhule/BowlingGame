﻿namespace BowlingBall.Interface
{
    internal interface IGame
    {
        bool IsSpare(int frameIndex);
        bool IsStrike(int frameIndex);
        void Roll(int pins);
        void Roll(int[] pins);
        int Score();
    }
}
